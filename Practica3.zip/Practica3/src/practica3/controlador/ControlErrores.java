package practica3.controlador;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class ControlErrores {
    public static String validarNumero(String numero) {
        try {
            int n = Integer.parseInt(numero);

            if (n <= 0) {
                return "El número debe ser mayor que cero";
            }

        } catch (NumberFormatException e) {
            return "El número debe ser un entero";
        }

        return null;
    }

    public static String validarNombre(String nombre) {
        if (nombre.trim().isEmpty()) {
            return "El nombre no puede estar vacío";
        }

        return null;
    }

    public static String validarPuntos(String puntos) {
        try {
            float p = Float.parseFloat(puntos);

            if (p < 0 || p > 1000) {
                return "Los puntos deben estar entre 0 y 1000";
            }

        } catch (NumberFormatException e) {
            return "Los puntos deben ser numéricos";
        }

        return null;
    }

    public static String validarFecha(String fecha) {
        try {
            LocalDate f = LocalDate.parse(fecha);

            if (f.getYear() < 1900 || f.getYear() > 2015) {
                return "El año debe estar entre 1900 y 2015";
            }

        } catch (DateTimeParseException e) {
            return "Fecha incorrecta. Formato: AAAA-MM-DD";
        }

        return null;
    }
}
