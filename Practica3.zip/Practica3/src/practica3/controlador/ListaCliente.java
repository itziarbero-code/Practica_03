package practica3.controlador;

import java.util.ArrayList;
import java.util.Comparator;
import practica3.modelo.Cliente;

public class ListaCliente extends ArrayList<Cliente> {
    private int actual;

    public ListaCliente() {
        actual = 0;
    }

    public boolean esVacia() {
        return this.isEmpty();
    }

    public void avanzar() {
        if (!isEmpty() && actual < size() - 1) {
            actual++;
        }
    }

    public void retroceder() {
        if (!isEmpty() && actual > 0) {
            actual--;
        }
    }

    public void irPrimero() {
        if (!isEmpty()) {
            actual = 0;
        }
    }

    public void irUltimo() {
        if (!isEmpty()) {
            actual = size() - 1;
        }
    }

    public boolean esPrimero() {
        return !isEmpty() && actual == 0;
    }

    public boolean esUltimo() {
        return !isEmpty() && actual == size() - 1;
    }

    public void anadirCliente(Cliente cliente) {
        add(cliente);
        actual = size() - 1;
    }

    public void borrarCliente() {
        if (!isEmpty()) {
            remove(actual);

            if (actual >= size() && !isEmpty()) {
                actual = size() - 1;
            }

            if (isEmpty()) {
                actual = 0;
            }
        }
    }

    public Cliente obtenerActual() {
        if (isEmpty()) {
            return null;
        }

        return get(actual);
    }

    public void ordenarPorNumero() {
        sort(Comparator.comparingInt(Cliente::getNumero));
        actual = 0;
    }

    public int getActual() {
        return actual;
    }
    
}
