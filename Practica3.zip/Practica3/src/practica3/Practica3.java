package practica3;
import javax.swing.SwingUtilities;
import practica3.vista.VentanaPrincipal;

public class Practica3 {

    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(() -> {
            new VentanaPrincipal();
        });

    }
    
}
